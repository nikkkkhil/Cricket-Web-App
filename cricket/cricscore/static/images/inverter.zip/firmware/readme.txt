Use stm32_sineHWCONFIG_REV1.bin for updating a V1 board without CAN function.
Use stm32_sineHWCONFIG_REV2.bin for updating a V2 board with CAN function
