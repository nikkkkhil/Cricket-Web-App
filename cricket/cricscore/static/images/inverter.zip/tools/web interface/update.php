<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" >
<title>Inverter Update</title>
<style>
            .graph {
                width: 500px; /* width and height are arbitrary, just make sure the #bar styles are changed accordingly */
                height: 30px;
                border: 1px solid #888; 
                background: rgb(168,168,168);
                background: -moz-linear-gradient(top, rgba(168,168,168,1) 0%, rgba(204,204,204,1) 23%);
                background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(168,168,168,1)), color-stop(23%,rgba(204,204,204,1)));
                background: -webkit-linear-gradient(top, rgba(168,168,168,1) 0%,rgba(204,204,204,1) 23%);
                background: -o-linear-gradient(top, rgba(168,168,168,1) 0%,rgba(204,204,204,1) 23%);
                background: -ms-linear-gradient(top, rgba(168,168,168,1) 0%,rgba(204,204,204,1) 23%);
                filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#a8a8a8', endColorstr='#cccccc',GradientType=0 );
                background: linear-gradient(top, rgba(168,168,168,1) 0%,rgba(204,204,204,1) 23%);
                position: relative;
            }
            #bar {
                height: 29px; /* Not 30px because the 1px top-border brings it up to 30px to match #graph */
                background: rgb(255,197,120); 
                background: -moz-linear-gradient(top, rgba(255,197,120,1) 0%, rgba(244,128,38,1) 100%); 
                background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(255,197,120,1)), color-stop(100%,rgba(244,128,38,1))); 
                background: -webkit-linear-gradient(top, rgba(255,197,120,1) 0%,rgba(244,128,38,1) 100%); 
                background: -o-linear-gradient(top, rgba(255,197,120,1) 0%,rgba(244,128,38,1) 100%); 
                background: -ms-linear-gradient(top, rgba(255,197,120,1) 0%,rgba(244,128,38,1) 100%); 
                background: linear-gradient(top, rgba(255,197,120,1) 0%,rgba(244,128,38,1) 100%); 
                border-top: 1px solid #fceabb;
            }
            #bar p { position: absolute; text-align: center; width: 100%; margin: 0; line-height: 30px; }
            .error {
                /* These styles are arbitrary */
                background-color: #fceabb;
                padding: 1em;
                font-weight: bold;
                color: red;
                border: 1px solid red;
            }
</style>
</head>
<body>
Please wait while inverter firmware is being updated.
<?php
if (count($_FILES))
{
    $filename = tempnam("/tmp", "upd");
    $step = -1;
    $dev = $_POST['d'];
    move_uploaded_file($_FILES['updatefile']['tmp_name'], $filename);
}
else if (isset($_GET["filename"], $_GET["step"], $_GET["d"]))
{
    $filename = $_GET["filename"];
    $step = $_GET["step"];
    $dev = $_GET["d"];
}

exec("python updater.py -d $dev -f $filename -s $step", $output);

preg_match('/\w\s+[0-9]+\s\w+\/([0-9]+)\s\w+/', $output[0], $matches);
$pages = $matches[1];

$step++;
$progress = (int)(100 * $step / $pages);

$proto = $_SERVER["REQUEST_SCHEME"];
$server = $_SERVER["SERVER_NAME"];
$port = $_SERVER["SERVER_PORT"];
$script = $_SERVER["SCRIPT_NAME"];

if ($step >= $pages)
{
    unlink($filename);
    $reload = false;
    echo "<p>Update complete. <a href=\"index.php?d=$dev\">Return to main page</a>";
}
else
{
    $newUrl = "$proto://$server:$port$script?filename=$filename&step=$step&d=$dev";
    $reload = true;
}

?>
<div id="progress" class="graph">
<div id="bar" style="width:<?php echo $progress ?>%"><p><?php echo $progress ?>% complete</p>
</div>
</div>
<?php if ($reload) { ?>
    <script>window.location.href = <?php echo "\"$newUrl\";"; ?></script>
<?php } ?>
</body>
</html>
