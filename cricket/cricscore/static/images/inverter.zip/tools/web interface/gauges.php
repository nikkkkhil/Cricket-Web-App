<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" class="no-js" lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" >
<title>Huebner Inverter Management Console</title>
    <link href="css/jquery-ui/jquery-ui.css" rel="stylesheet" type="text/css" />
    
    <script src="js/base/jquery-latest.min.js" type="text/javascript"></script>
    <script src="js/base/jquery-ui.js" type="text/javascript"></script>
    <script src="tee/src/teechart.js" type="text/javascript"></script>
    <script src="tee/src/teechart-extras.js" type="text/javascript"></script>
    <script src="tee/src/date.format.js" type="text/javascript"></script>
    <script src="tee/src/teechart-gauges.js" type="text/javascript"></script>
    <script src="js/gauges.js" type="text/javascript"></script>
</head>
<body>
<?php
if (isset($_GET['i']))
{
    $items = $_GET['i'];
    $dev = $_GET['d'];
    $idx = 0;

    foreach ($items as $item)
    {
        echo "<canvas id=\"canvas_$item\" width=250 height=270></canvas>";
        $idx++;
    }
    echo "<script>
    var items = [ '" . implode("', '", $items) . "' ]; 
    var dev = '$dev';
    </script>";
}
else
{
    echo "No display values selected.";
}

?>
</body>
</html>

