var gauges = {};

$(document).ready(function() 
{
    createGauges();
    acquire();
});

/**
 * @brief Creates gauges for all canvases found on the page
 */
function createGauges()
{
	$("canvas").each(function() {
		var gauge=new Tee.Chart(this.id);
		gauge.footer.text = this.id.split("canvas_")[1];
		gauge.footer.format.font.fill="black";
		gauge.footer.margins.top = -40;
		gauge.title.visible = false;
		gauge.panel.transparent=true;
		
		var series = new Tee.CircularGauge();
		series.min = 0;
		series.max = 1;
		series.step = (series.max - series.min) / 6;
		series.mousedown = function() {};
		series.shape="segment";
		series.angle=220;
		gauge.addSeries(series);
		gauge.draw();
		gauges[this.id] = gauge;
	});
}

function acquire()
{
    if (!items.length) return;
    var xmlhttp=new XMLHttpRequest();
    var req = "getdata.php?i[]="+items.join('&i[]=')+"&s=1&d="+dev
    
    xmlhttp.onreadystatechange = function()
    {
       // acquire();
    }
    
    xmlhttp.onload = function() 
    {
        var newVals = JSON.parse(this.responseText);
        
        var signalIdx = 0;
        $("canvas").each(function() {
            var val = newVals[signalIdx][0];
            var series = gauges[this.id].series.items[0];
            series.value = val;
            series.min = Math.min(series.min, Math.floor(val));
            series.max = Math.max(series.max, Math.ceil(val));
    		series.step = (series.max - series.min) / 6;
            gauges[this.id].draw()
            signalIdx++;
        });
        acquire();
    }
    xmlhttp.open("GET", req, true);
    xmlhttp.send();
}
