/**
 * Console fix
 */
if (!window.console) {
	window.console = {
		log		: function (event) {},
		info	: function (event) {},
		warn	: function (event) {},
		error	: function (event) {}
	};
}

// Self calling anonymous function to make of use the $ shortcut
// Even when using jQuery.noConflict();
(function ($) {
	// Short form of $(document).ready();
	$(function () {
		// Code goes here  …
	});
}(jQuery));