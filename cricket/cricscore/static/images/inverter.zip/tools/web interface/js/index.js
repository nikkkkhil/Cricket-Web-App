var _chart;
var _stop = true;
var _paused = false;
var _prevItems = new Array();
var _imgid = 0;
var _plotItems;

$(document).ready(function() 
{
    _chart=new Tee.Chart("canvas");
    _chart.legend.legendStyle = "series";
    _chart.title.visible = false;
    _chart.draw();
    $("#params input").keyup(onParamKeyUp);
    
    $('#params').dataTable({
		'bJQueryUI': true,
		'bPaginate': false,
		'bLengthChange': false,
		'oLanguage': dataTablesLanguage
	}).rowGrouping({bExpandableGrouping: true, iGroupingColumnIndex: 0});
});

function onParamKeyUp(e)
{
    if ("Enter" == e.key)
    {
        sendCmd("set "+this.name+" "+this.value);
    }
}

function sendCmd(cmd)
{
    var xmlhttp=new XMLHttpRequest();
    var req = "sendcmd.php?cmd="+cmd+"&d="+dev;
    var delay = 0;
    
    xmlhttp.onload = function() 
    {
        if (this.plotResume) pauseResume();
        $("#message").html(this.responseText);
    }
    
    xmlhttp.open("GET", req, true);
    pausePlotAndSend(xmlhttp);
}

function showGauges()
{
    var items = new Array();
    $('#spotValues input').each(function() 
    {
        if (this.checked)
        {
            items.push($(this).data('name'));
        }
    });
    var req = "gauges.php?i[]="+items.join('&i[]=')+"&d="+dev
    
    window.open(req);
}

function canmap(name)
{
    var canid = $('#canid' + name).val();
    var canpos = $('#canpos' + name).val();
    var canbits = $('#canbits' + name).val();
    var cangain = $('#cangain' + name).val();
    var cmd = "can tx " + name + " " + canid + " " + canpos + " " + canbits + " " + cangain;
    
    sendCmd(cmd);
}

function updateTables()
{
    var xmlhttp=new XMLHttpRequest();
    var req = "getdata.php?i[]=all"+"&d="+dev;
    $("#message").html("Updating...");
    
    xmlhttp.onload = function() 
    {
        var newVals = JSON.parse(this.responseText);
        $("#message").html("Update Done.");
        if (this.plotResume) pauseResume();
        
        for (var name in newVals)
        {
            var value = newVals[name].value;
            var elem = document.getElementById("val"+name);
            
            if (elem.options) //this is a list box
            {
                for (var i = 0; i < elem.options.length; i++)
                {
                    if (elem.options[i].value == value)
                        break;
                }
                elem.selectedIndex = i;
            }
            else if (elem.value) //this is an edit control
            {
                elem.value = value;
            }
            else //This is static text
            {
                if (enumVals[name])
                    value = enumVals[name][value];
                elem.firstChild.textContent = value;
            }
        }
    }
    xmlhttp.open("GET", req, true);
    pausePlotAndSend(xmlhttp);
}

function pausePlotAndSend(xmlhttp)
{
    var delay = 0;

    if (!_stop && !_paused)
    {
        pauseResume();
        delay = 1500;
        $("#message").html("Pausing plot...");
    }
        
    setTimeout(function()
    {
        xmlhttp.plotResume = delay > 0;
        xmlhttp.send();
    }, delay);
}

function start()
{
    var items = {};
    items.names = new Array();
    items.axes = new Array();
    
    $('#spotValues input').each(function() 
    {
        if (this.checked)
        {
            items.names.push($(this).data('name'));
            items.axes.push($(this).data('axis'));
        }
    });
    
    _chart.series.items = new Array();
    _chart.axes.left.title.text = "";
    _chart.axes.right.title.text = "";

    for (var signalIdx = 0; signalIdx < items.names.length; signalIdx++)
    {
        var item = items.names[signalIdx];
        var axis = items.axes[signalIdx];
        
        var series = new Tee.Line();
        series.title = item;
        series.vertAxis = axis;
        
        _chart.addSeries(series);
        _chart.axes[axis].title.text += item + ", ";
    }
    _chart.draw();
    _plotItems = items;
    _stop = false;
    $("#pauseButton").prop("disabled", false);

    acquire(_chart, items);
}

function stop()
{
    _stop = true;
    $("#pauseButton").text("Pause Plot");
    $("#pauseButton").prop("disabled", true);
}

function pauseResume()
{
    if (_paused)
    {
        _stop = false;
        acquire(_chart, _plotItems);
        $("#pauseButton").text("Pause Plot");
    }
    else
    {
        _stop = true;
        $("#pauseButton").text("Resume Plot");
    }
    
    _paused = !_paused;
}

function save()
{
    appendHtmlToBody('<p><img id="plotpngimage'+_imgid+'"></p>');
    _chart.toImage('plotpngimage'+_imgid, 'image/png');
    _imgid++;
}

function acquire(chart, items)
{
    if (_stop) return;
    if (!items.names.length) return;
    var xmlhttp=new XMLHttpRequest();
    var req = "getdata.php?i[]="+items.names.join('&i[]=')+"&s=10&r=0.1&d="+dev
    
    xmlhttp.onreadystatechange = function()
    {
        if (this.status==500)
            acquire(chart, items);
    }
    
    xmlhttp.onload = function() 
    {
        var newVals = JSON.parse(this.responseText);
        
        for (var signalIdx = 0; signalIdx < items.names.length; signalIdx++)
        {
            var item = items.names[signalIdx];
            var data = chart.series.items[signalIdx].data;
            
            data.values = data.values.concat(newVals[signalIdx]);
        }
        
        recalcAxisMinMax(chart.axes.left);
        recalcAxisMinMax(chart.axes.right);
        
        chart.draw();
        acquire(chart, items);
    }
    xmlhttp.open("GET", req, true);
    xmlhttp.send();
}

function recalcAxisMinMax(axis)
{
    axis.automatic=true;
    axis.checkMinMax();
    var incr = Math.abs(axis.maximum - axis.minimum) / 50;
    axis.setMinMax(axis.minimum - incr, axis.maximum + 2*incr);
}

function createHtmlFragment(htmlStr) 
{
    var frag = document.createDocumentFragment();
    var temp = document.createElement('div');
    temp.innerHTML = htmlStr;
    while (temp.firstChild) 
    {
        frag.appendChild(temp.firstChild);
    }
    return frag;
}

function appendHtmlToBody(htmlStr)
{
    var fragment = createHtmlFragment(htmlStr);
    // You can use native DOM methods to insert the fragment:
    document.body.appendChild(fragment);
}
