<?php

require('php-serial/php_serial.class.php');
require('config.inc.php');
require('InverterTerminal.class.php');

$term = new InverterTerminal($serial);

$items = $_GET['i'];
$chunkSize = 100;

if (isset($_GET['s']))
    $chunkSize = $_GET['s'];

$responseTime = count($items) * 10 * (11 / 115200);

if (isset($_GET['r']))
    $responseTime = $_GET['r'];

$values = array();
if ($items[0] == "all")
{
    $term->getValues($values);
}
else
{
    $itemsCs = implode(",", $items);
    $lines = $term->sendCmd("get $itemsCs\n", true, $responseTime * 2);

    for ($i = 0; $i < $chunkSize; $i++)
    {
        for ($j = 0; $j < count($lines); $j++)
        {
            $values[$j][] = round($lines[$j], 2);
        }
        
        $lines = $term->repeatCmd($responseTime);
    }
}

echo json_encode($values);

/*$_SESSION['items'] = $items;
if (!isset($_SESSION['values']) || isset($_GET['reset'])) $_SESSION['values'] = $values;
else $_SESSION['values'] = array_merge($_SESSION['values'], $values);*/

?>