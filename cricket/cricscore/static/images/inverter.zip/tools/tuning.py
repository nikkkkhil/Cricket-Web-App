import serial, time, math
from optparse import OptionParser

parser = OptionParser()
parser.add_option("-f", "--file", dest="filename",
                  help="update file")
parser.add_option("-d", "--device", dest="device",
                  help="serial interface")
parser.add_option("-v", "--verbose", dest="verbose", default=False,action="store_true",
                  help="verbose mode")

(options, args) = parser.parse_args()

#if not options.filename:   # if filename is not given
#    parser.error('Filename not given')
#    exit()
if not options.device:   # if device is not given
    parser.error('Device not given')
    exit()
ser = serial.Serial(options.device, 115200, timeout=1, stopbits=2)

def sendCommand(cmd,consumeReply=False):
	ser.flushInput()
	time.sleep(0.1)
	ser.write(cmd)
	ser.write("\n")
	s = ser.readline() #consume echo
	if options.verbose:
		print " > %s" % s
	time.sleep(0.1) #wait for command to execute

	if consumeReply:
		s = ser.readline() #consume reply
		if options.verbose:
			print " < %s" % s

def getScalar(name):
	sendCommand("get %s" % name)
	return float(ser.readline())

def getAverage(name):
	sendCommand("get %s" % name)
	sum = 0
	for i in range(0,10):
		ser.write("!")
		time.sleep(0.1)
		sum = sum + float(ser.readline().strip("!"))
	return sum / 10

def rampFrequency(_from, to):
	for framp in range(_from, to + 1):
		sendCommand("set fslipspnt %d" % framp)

def sanityCheck():
	checkDone = False
	while not checkDone:
		ser.flushInput()
		sendCommand("get version,din_mprot,din_emcystop,din_forward,din_reverse,din_ocur")
		version = float(ser.readline())
		mprot = float(ser.readline())
		emcystop = float(ser.readline())
		forward = float(ser.readline())
		reverse = float(ser.readline())
		ocur = float(ser.readline())

		if version < 3.18:
			print "You need at least firmware version 3.18 to run this program"
			exit()

		if 0 == mprot:
			print "Motor Protection Input (Pin 11) needs to be connected to 12V to continue"
		elif 0 == emcystop:
			print "Emergency Stop Input (Pin 17) needs to be connected to 12V to continue"
		elif 1 == ocur:
			print "The overcurrent limit is tripped, please check il1gain, il2gain and ocurlim, they must have the same sign"
		elif 0 == forward and 0 == reverse or 1 == forward and 1 == reverse:
			print "Either forward or reverse must be connected to 12V to continue"
		else:
			print "Sanity check passed, continuing"
			checkDone = True

		if not checkDone:
			raw_input("Correct errer then press Enter to try again...")

def modeCheck():
	opmode = getScalar("opmode")
	if 1 == opmode or 4 == opmode:
		return
	
	print "Now start the inverter with the start signal Pin 7"
	checkDone = False

	while not checkDone:
		opmode = getScalar("opmode")

		if 1 == opmode or 4 == opmode:
			checkDone = True

		if not checkDone:
			time.sleep(1)
	time.sleep(2)

def boostTuning(ampMax):
	sendCommand("set fweak 400", True)
	sendCommand("set boost 0", True)

	print "Now put the car into the highest gear and pull the handbrake, torque will be put on the motor!!"
	raw_input("Press Enter to continue")

	sendCommand("set fslipspnt 1.5", True)
	sendCommand("set ampnom 100", True)

	current = 0
	boost = 900

	while current < ampMax:
		boost = boost + max((ampMax - current) * 10, 50)
		sendCommand("set boost %d" % boost, True)
		time.sleep(0.5)
		current = getAverage("il1rms")
		print current
		time.sleep(0.1)

	sendCommand("set ampnom 0")
	print "A boost value of %d results in your required current" % boost
	return ampMax

def fweakTuning(ampnom):
	print "Very little torque is now put on the motor. The shaft should not spin. If it does, lock it"
	fmax = getScalar("fmax")
	sendCommand("set fslipspnt 0")
	sendCommand("set fmax 1000")
	sendCommand("set ampnom %d" % ampnom)

	fweak = 200

	checkDone = False

	while not checkDone:
		i2 = fweak
		i1 = i2 / 2
		sendCommand("set fweak %d" % fweak)
		print "Trying fweak %d" % fweak

		sendCommand("set fslipspnt %d" % i1, True)
		time.sleep(1)
		currentStart = getAverage("il2rms")
		time.sleep(1)
		sendCommand("set fslipspnt %d" % i2, True)
		time.sleep(1)
		currentEnd = getAverage("il2rms")
		sendCommand("set fslipspnt 0")

		ratio = currentEnd / currentStart
		print ratio, currentStart, currentEnd
		#This is basically a locked rotor test. Twice the frequency transfers
		#twice as much energy onto the rotor. Therefor we expect twice the current
		if ratio < 2.2 and ratio > 2:
			print "A value of %d for fweak will result in even torque over the frequency range" % fweak
			checkDone = True
		else:
			fweak = fweak * (ratio / 2.1)
			
			if fweak < 10 or fweak > 990:
				print "Out of range, please check your power supply"
				checkDone = True
				
	sendCommand("set fmax %d" % fmax)


def polePairTest():
	print "Now mark your motor shaft with something to observe when it finishes a rotation"
	print "Will now slowly spin the shaft"
	raw_input("Press Enter to continue")
	sendCommand("set ampnom 50")
	sendCommand("set fslipspnt 2")
	time.sleep(10)
	sendCommand("set fslipspnt 0")
	turns = input("How many turns did the shaft complete in 10s? (Round up) ")
	polepairs = math.floor(20/turns)
	print "The motor has %d pole pairs" % polepairs
	sendCommand("set polepairs %d" % polepairs)
	return polepairs

def numimpTest(polepairs):
	print "We will now spin the motor shaft @60Hz and try to determine how many pulses per rotation we get"
	raw_input("Press Enter to continue")
	sendCommand("set numimp 8", True)
	sendCommand("set ampnom 70", True)
	expectedSpeed = 59.9*60 / polepairs
	rampFrequency(0, 60)
	time.sleep(2)
	speed = getAverage("speed")
	sendCommand("set ampnom 0")
	numimp = round(speed / expectedSpeed * 8)
	print "Your encoder seems to have %d pulses per rotation" % numimp
	sendCommand("set numimp %d" % numimp, True)

print "Welcome to the inverter tuning wizward"
print "This program will help you to set up the inverter for your motor and battery pack"
print "It is meant for in-car tuning with your intended battery pack voltage"
print "It can also be used on your bench for first checks"
print "First we will check if the inverter is operational"

sanityCheck()
modeCheck()

print "Putting inverter into raw sine mode"
sendCommand("start 4", True)

ampMax = 0
if "y" == raw_input("Peform boost tuning [y/N]? "):
	ampMax = input("What is your intended RMS motor current [A]? ")
	boostTuning(ampMax)

if "y" == raw_input("Peform fweak tuning [y/N]? "):
	fweakTuning(10)
	
if "y" == raw_input("Peform polepairs test [y/N]? "):
	polepairs = polePairTest()
else:
	polepairs = getScalar("polepairs")

if "y" == raw_input("Peform numimp test [y/N]? "):
	numimpTest(polepairs)
	
if "y" == raw_input("Save parameters to flash [y/N]? "):
	sendCommand("save", True)
